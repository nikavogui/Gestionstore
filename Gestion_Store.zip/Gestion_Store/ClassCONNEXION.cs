﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Store
{
    class ClassCONNEXION
    {
        private MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;uid=root;password=nikavogui1992;database=gestionstore");
        //Creation de la fonction pour retourner la connexion
        public MySqlConnection GetConnection()
        {
            try
            {
                return connection;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //Creation d'une fonction pour ouvrir la connexion

        public void openConnection()
        {
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        //Creation d'une fonction pour fermer la connexion

        public void closeConnection()
        {
            try
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }
    }
}
