﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Store
{
    public partial class FormCLIENTS : Form
    {
        ClassCLIENTS classCLIENTS = new ClassCLIENTS();
        public FormCLIENTS()
        {
            InitializeComponent();
        }

        private void FormCLIENTS_Load(object sender, EventArgs e)
        {
            try
            {
                textBoxID.Text = "0000";
                textBoxNOM.Text = "";
                textBoxPRENOMS.Text = "";
                maskedTextBoxTELEPHONE.Text = "";
                textBoxFRAIS.Text = string.Format("{0:n}",35000);
                dateTimePickerDATE.Value =DateTime.Now.Date;

                comboBoxRECHERCHER.DataSource = classCLIENTS.nomClient();
                comboBoxRECHERCHER.DisplayMember = "nomClt";
                comboBoxRECHERCHER.ValueMember = "";
                comboBoxRECHERCHER.Text = "";
                
                dataGridViewLISTEENREGISTRES.DataSource = classCLIENTS.ClientInformations(comboBoxRECHERCHER.Text);
                textBoxNOM.Select();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void buttonENREGISTRER_Click(object sender, EventArgs e)
        {
            try
            {
                int id;
                string nom;
                string prenoms;
                string tel;
                double frais;
                DateTime dateEnreg;

                id = Convert.ToInt32(textBoxID.Text);
                nom = textBoxNOM.Text.ToUpper();
                prenoms = textBoxPRENOMS.Text.ToUpper();
                tel = maskedTextBoxTELEPHONE.Text;
                frais =Convert.ToDouble(textBoxFRAIS.Text);
                dateEnreg =Convert.ToDateTime(dateTimePickerDATE.Value);
                
                if (id == 0)
                {
                    if (textBoxNOM.Text.Trim().Equals(""))
                    {
                        MessageBox.Show("ENTRER LE NOM DU CLIENT", "NOM CLIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBoxNOM.Select();
                    }
                    else if (textBoxPRENOMS.Text.Trim().Equals(""))
                    {
                        MessageBox.Show("ENTRER LE PRENOMS DU CLIENT", "PRENOMS CLIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBoxPRENOMS.Select();
                    }
                    else if (maskedTextBoxTELEPHONE.Text.Trim().Equals(""))
                    {
                        MessageBox.Show("ENTRER LE NUMERO DE TELEPHONE DU CLIENT", "TELEPHONE CLIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        maskedTextBoxTELEPHONE.Select();
                    }
                    else if (frais<=0)
                    {
                        MessageBox.Show("LES FRAIS D'ABONNEMENT >0", "FRAIS ABONNEMENT CLIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBoxFRAIS.Select();
                    }
                    else
                    {
                            bool ajoutClient = classCLIENTS.ajoutClient(nom, prenoms, tel, frais, dateEnreg);
                            if (ajoutClient)
                            {
                                MessageBox.Show("Client(e) Enregistré(e) avec Succès", "Enregistrement Client", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            textBoxID.Text = "0000";
                            textBoxNOM.Text = "";
                            textBoxPRENOMS.Text = "";
                            maskedTextBoxTELEPHONE.Text = "";
                            textBoxFRAIS.Text = string.Format("{0:n}", 35000);
                            dateTimePickerDATE.Text = "";

                            comboBoxRECHERCHER.DataSource = classCLIENTS.nomClient();
                            comboBoxRECHERCHER.DisplayMember = "nomClt";
                            comboBoxRECHERCHER.ValueMember = "";
                            comboBoxRECHERCHER.Text = "";

                            dataGridViewLISTEENREGISTRES.DataSource = classCLIENTS.ClientInformations(comboBoxRECHERCHER.Text);
                            
                            textBoxNOM.Select();
                        }
                    }
                }
                else
                {
                    if (textBoxNOM.Text.Trim().Equals(""))
                    {
                        MessageBox.Show("ENTRER LE NOM DU CLIENT", "NOM CLIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBoxNOM.Select();
                    }
                    else if (textBoxPRENOMS.Text.Trim().Equals(""))
                    {
                        MessageBox.Show("ENTRER LE PRENOMS DU CLIENT", "PRENOMS CLIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBoxPRENOMS.Select();
                    }
                    else if (maskedTextBoxTELEPHONE.Text.Trim().Equals(""))
                    {
                        MessageBox.Show("ENTRER LE NUMERO DE TELEPHONE DU CLIENT", "TELEPHONE CLIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        maskedTextBoxTELEPHONE.Select();
                    }
                    else if (frais <= 0)
                    {
                        MessageBox.Show("LES FRAIS D'ABONNEMENT >0", "FRAIS ABONNEMENT CLIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBoxFRAIS.Select();
                    }
                    else
                    {
                        bool MAJClient = classCLIENTS.MAJClients(id, nom, prenoms, tel, frais, dateEnreg);
                        if (MAJClient)
                        {
                            MessageBox.Show("Informations du Client Enregistrées avec Succès", "Mise à Jour Client", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            textBoxID.Text = "0000";
                            textBoxNOM.Text = "";
                            textBoxPRENOMS.Text = "";
                            maskedTextBoxTELEPHONE.Text = "";
                            textBoxFRAIS.Text = string.Format("{0:n}", 35000);
                            dateTimePickerDATE.Text = "";

                            comboBoxRECHERCHER.DataSource = classCLIENTS.nomClient();
                            comboBoxRECHERCHER.DisplayMember = "nomClt";
                            comboBoxRECHERCHER.ValueMember = "";
                            comboBoxRECHERCHER.Text = "";

                            dataGridViewLISTEENREGISTRES.DataSource = classCLIENTS.ClientInformations(comboBoxRECHERCHER.Text);

                            textBoxNOM.Select();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void buttonANNULER_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxID.Text = "0000";
                textBoxNOM.Text = "";
                textBoxPRENOMS.Text = "";
                maskedTextBoxTELEPHONE.Text = "";
                textBoxFRAIS.Text = string.Format("{0:n}", 35000);
                dateTimePickerDATE.Text = "";

                comboBoxRECHERCHER.DataSource = classCLIENTS.nomClient();
                comboBoxRECHERCHER.DisplayMember = "nomClt";
                comboBoxRECHERCHER.ValueMember = "";
                comboBoxRECHERCHER.Text = "";
                dataGridViewLISTEENREGISTRES.DataSource = classCLIENTS.ClientInformations(comboBoxRECHERCHER.Text);
                textBoxNOM.Select();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void buttonSUPPRIMER_Click(object sender, EventArgs e)
        {
            try
            {
                int id;
                id = Convert.ToInt32(textBoxID.Text);
                if (id == 0)
                {
                    MessageBox.Show("Selectionner le Client que vous vouliez supprimer", "CLIENT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    
                    dataGridViewLISTEENREGISTRES.Select();
                }
                else
                {
                    DialogResult result = MessageBox.Show("Voulez-vous vraiment supprimer ce Client?", "CONFIRMATION SUPPRESSION", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        bool delete = classCLIENTS.deleteClient(id);
                        if (delete)
                        {
                            MessageBox.Show("Client Supprimer avec succès", "Supprimer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            textBoxID.Text = "0000";
                            textBoxNOM.Text = "";
                            textBoxPRENOMS.Text = "";
                            maskedTextBoxTELEPHONE.Text = "";
                            textBoxFRAIS.Text = string.Format("{0:n}", 35000);
                            dateTimePickerDATE.Text = "";

                            comboBoxRECHERCHER.DataSource = classCLIENTS.nomClient();
                            comboBoxRECHERCHER.DisplayMember = "nomClt";
                            comboBoxRECHERCHER.ValueMember = "";
                            comboBoxRECHERCHER.Text = "";

                            dataGridViewLISTEENREGISTRES.DataSource = classCLIENTS.ClientInformations(comboBoxRECHERCHER.Text);

                            textBoxNOM.Select();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Suppression Annulée", "Suppression Annulée", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridViewLISTEENREGISTRES_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                textBoxID.Text = dataGridViewLISTEENREGISTRES.CurrentRow.Cells[0].Value.ToString();
                textBoxNOM.Text = dataGridViewLISTEENREGISTRES.CurrentRow.Cells[1].Value.ToString();
                textBoxPRENOMS.Text = dataGridViewLISTEENREGISTRES.CurrentRow.Cells[2].Value.ToString();
                maskedTextBoxTELEPHONE.Text = dataGridViewLISTEENREGISTRES.CurrentRow.Cells[3].Value.ToString();
                textBoxFRAIS.Text = string.Format("{0:n}", Convert.ToDouble(dataGridViewLISTEENREGISTRES.CurrentRow.Cells[4].Value.ToString()));
                dateTimePickerDATE.Value =Convert.ToDateTime(dataGridViewLISTEENREGISTRES.CurrentRow.Cells[5].Value.ToString()).Date;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBoxFRAIS_Leave(object sender, EventArgs e)
        {
            textBoxFRAIS.Text = string.Format("{0:n}", Convert.ToDouble(textBoxFRAIS.Text));
        }

        private void comboBoxRECHERCHER_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dataGridViewLISTEENREGISTRES.DataSource = classCLIENTS.ClientInformations(comboBoxRECHERCHER.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "EXCEPTION MESSAGE", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
    }
}
