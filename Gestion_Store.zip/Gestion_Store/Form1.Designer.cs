﻿
namespace Gestion_Store
{
    partial class FormCLIENTS
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.textBoxNOM = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxFRAIS = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxPRENOMS = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.maskedTextBoxTELEPHONE = new System.Windows.Forms.MaskedTextBox();
            this.dateTimePickerDATE = new System.Windows.Forms.DateTimePicker();
            this.dataGridViewLISTEENREGISTRES = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBoxRECHERCHER = new System.Windows.Forms.ComboBox();
            this.buttonENREGISTRER = new System.Windows.Forms.Button();
            this.buttonSUPPRIMER = new System.Windows.Forms.Button();
            this.buttonANNULER = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLISTEENREGISTRES)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.comboBoxRECHERCHER);
            this.panel1.Controls.Add(this.dataGridViewLISTEENREGISTRES);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(9, 6);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1172, 469);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(13, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1153, 92);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(77, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1024, 54);
            this.label1.TabIndex = 0;
            this.label1.Text = "FORMULAIRE ENREGISTREMENT CLIENTS";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonANNULER);
            this.groupBox1.Controls.Add(this.buttonSUPPRIMER);
            this.groupBox1.Controls.Add(this.buttonENREGISTRER);
            this.groupBox1.Controls.Add(this.dateTimePickerDATE);
            this.groupBox1.Controls.Add(this.maskedTextBoxTELEPHONE);
            this.groupBox1.Controls.Add(this.textBoxPRENOMS);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.textBoxFRAIS);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBoxNOM);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBoxID);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(13, 107);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(422, 346);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DETAILS DU CLIENT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(123, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "ID";
            // 
            // textBoxID
            // 
            this.textBoxID.Enabled = false;
            this.textBoxID.Location = new System.Drawing.Point(161, 51);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(231, 29);
            this.textBoxID.TabIndex = 0;
            // 
            // textBoxNOM
            // 
            this.textBoxNOM.Location = new System.Drawing.Point(161, 93);
            this.textBoxNOM.Name = "textBoxNOM";
            this.textBoxNOM.Size = new System.Drawing.Size(231, 29);
            this.textBoxNOM.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(94, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "NOM";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = "DATE ENREG.";
            // 
            // textBoxFRAIS
            // 
            this.textBoxFRAIS.Location = new System.Drawing.Point(161, 215);
            this.textBoxFRAIS.Name = "textBoxFRAIS";
            this.textBoxFRAIS.Size = new System.Drawing.Size(231, 29);
            this.textBoxFRAIS.TabIndex = 4;
            this.textBoxFRAIS.Leave += new System.EventHandler(this.textBoxFRAIS_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 24);
            this.label5.TabIndex = 6;
            this.label5.Text = "FRAIS ABON.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 179);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 24);
            this.label6.TabIndex = 8;
            this.label6.Text = "TELEPHONE";
            // 
            // textBoxPRENOMS
            // 
            this.textBoxPRENOMS.Location = new System.Drawing.Point(161, 134);
            this.textBoxPRENOMS.Name = "textBoxPRENOMS";
            this.textBoxPRENOMS.Size = new System.Drawing.Size(231, 29);
            this.textBoxPRENOMS.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 139);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 24);
            this.label7.TabIndex = 10;
            this.label7.Text = "PRENOMS";
            // 
            // maskedTextBoxTELEPHONE
            // 
            this.maskedTextBoxTELEPHONE.Location = new System.Drawing.Point(161, 174);
            this.maskedTextBoxTELEPHONE.Mask = "(+224) 000 00 00 00";
            this.maskedTextBoxTELEPHONE.Name = "maskedTextBoxTELEPHONE";
            this.maskedTextBoxTELEPHONE.Size = new System.Drawing.Size(231, 29);
            this.maskedTextBoxTELEPHONE.TabIndex = 3;
            // 
            // dateTimePickerDATE
            // 
            this.dateTimePickerDATE.CustomFormat = "dd-MM-yyyy";
            this.dateTimePickerDATE.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerDATE.Location = new System.Drawing.Point(164, 253);
            this.dateTimePickerDATE.Name = "dateTimePickerDATE";
            this.dateTimePickerDATE.Size = new System.Drawing.Size(227, 29);
            this.dateTimePickerDATE.TabIndex = 5;
            // 
            // dataGridViewLISTEENREGISTRES
            // 
            this.dataGridViewLISTEENREGISTRES.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewLISTEENREGISTRES.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewLISTEENREGISTRES.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLISTEENREGISTRES.GridColor = System.Drawing.Color.Black;
            this.dataGridViewLISTEENREGISTRES.Location = new System.Drawing.Point(450, 179);
            this.dataGridViewLISTEENREGISTRES.Name = "dataGridViewLISTEENREGISTRES";
            this.dataGridViewLISTEENREGISTRES.ReadOnly = true;
            this.dataGridViewLISTEENREGISTRES.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewLISTEENREGISTRES.Size = new System.Drawing.Size(716, 272);
            this.dataGridViewLISTEENREGISTRES.TabIndex = 10;
            this.dataGridViewLISTEENREGISTRES.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewLISTEENREGISTRES_CellClick);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(526, 135);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(152, 24);
            this.label8.TabIndex = 15;
            this.label8.Text = "RECHERCHER";
            // 
            // comboBoxRECHERCHER
            // 
            this.comboBoxRECHERCHER.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.comboBoxRECHERCHER.FormattingEnabled = true;
            this.comboBoxRECHERCHER.Location = new System.Drawing.Point(685, 130);
            this.comboBoxRECHERCHER.Name = "comboBoxRECHERCHER";
            this.comboBoxRECHERCHER.Size = new System.Drawing.Size(319, 32);
            this.comboBoxRECHERCHER.TabIndex = 9;
            this.comboBoxRECHERCHER.TextChanged += new System.EventHandler(this.comboBoxRECHERCHER_TextChanged);
            // 
            // buttonENREGISTRER
            // 
            this.buttonENREGISTRER.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buttonENREGISTRER.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.buttonENREGISTRER.ForeColor = System.Drawing.Color.White;
            this.buttonENREGISTRER.Location = new System.Drawing.Point(21, 298);
            this.buttonENREGISTRER.Name = "buttonENREGISTRER";
            this.buttonENREGISTRER.Size = new System.Drawing.Size(131, 30);
            this.buttonENREGISTRER.TabIndex = 6;
            this.buttonENREGISTRER.Text = "Enregistrer";
            this.buttonENREGISTRER.UseVisualStyleBackColor = false;
            this.buttonENREGISTRER.Click += new System.EventHandler(this.buttonENREGISTRER_Click);
            // 
            // buttonSUPPRIMER
            // 
            this.buttonSUPPRIMER.BackColor = System.Drawing.Color.Maroon;
            this.buttonSUPPRIMER.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.buttonSUPPRIMER.Location = new System.Drawing.Point(287, 298);
            this.buttonSUPPRIMER.Name = "buttonSUPPRIMER";
            this.buttonSUPPRIMER.Size = new System.Drawing.Size(119, 30);
            this.buttonSUPPRIMER.TabIndex = 8;
            this.buttonSUPPRIMER.Text = "Supprimer";
            this.buttonSUPPRIMER.UseVisualStyleBackColor = false;
            this.buttonSUPPRIMER.Click += new System.EventHandler(this.buttonSUPPRIMER_Click);
            // 
            // buttonANNULER
            // 
            this.buttonANNULER.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonANNULER.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.buttonANNULER.Location = new System.Drawing.Point(161, 298);
            this.buttonANNULER.Name = "buttonANNULER";
            this.buttonANNULER.Size = new System.Drawing.Size(119, 30);
            this.buttonANNULER.TabIndex = 7;
            this.buttonANNULER.Text = "Annuler";
            this.buttonANNULER.UseVisualStyleBackColor = false;
            this.buttonANNULER.Click += new System.EventHandler(this.buttonANNULER_Click);
            // 
            // FormCLIENTS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1187, 487);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FormCLIENTS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FORMULAIRE CLIENTS";
            this.Load += new System.EventHandler(this.FormCLIENTS_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLISTEENREGISTRES)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridViewLISTEENREGISTRES;
        private System.Windows.Forms.DateTimePicker dateTimePickerDATE;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxTELEPHONE;
        private System.Windows.Forms.TextBox textBoxPRENOMS;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxFRAIS;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxNOM;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxRECHERCHER;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonANNULER;
        private System.Windows.Forms.Button buttonSUPPRIMER;
        private System.Windows.Forms.Button buttonENREGISTRER;
    }
}

