-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 25 fév. 2021 à 12:38
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gestionstore`
--

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `idClt` int(11) NOT NULL AUTO_INCREMENT,
  `nomClt` varchar(45) DEFAULT NULL,
  `prenomsClt` varchar(45) DEFAULT NULL,
  `telClt` varchar(45) DEFAULT NULL,
  `fraisAbon` double DEFAULT NULL,
  `dateEnreg` date DEFAULT NULL,
  PRIMARY KEY (`idClt`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`idClt`, `nomClt`, `prenomsClt`, `telClt`, `fraisAbon`, `dateEnreg`) VALUES
(23, 'DIALLO', 'AMADOU', '(+224) 098 20 94 82', 35000, '2021-02-25'),
(19, 'NIKAVOGUI', 'JEAN MICHEL', '(+224) 828 97 89 27', 35000, '2021-02-25'),
(21, 'LAMAH', 'ALPHA OUMAR', '(+224) 892 74 92 79', 35000, '2021-02-25'),
(24, 'NIKAVOGUI', 'HERVE', '(+224) 789 47 29 83', 35000, '2021-02-25'),
(26, 'HABA', 'EMILE THEO', '(+224) 279 04 28 79', 35000, '2021-02-25'),
(27, 'BALAMOU', 'BERNARD', '(+224) 029 84 09 28', 35000, '2021-02-25');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
