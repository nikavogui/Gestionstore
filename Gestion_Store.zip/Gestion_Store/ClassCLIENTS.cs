﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Store
{
    class ClassCLIENTS
    {
        ClassCONNEXION con = new ClassCONNEXION();
        
        public DataTable nomClient()
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "SELECT distinct nomClt FROM clients GROUP BY nomClt;";
            command.Connection = con.GetConnection();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = command;
            DataTable data = new DataTable();
            adapter.Fill(data);
            return data;
        }
        public DataTable ClientInformations(string nom)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "SELECT `idClt` as ID,`nomClt` AS NOM,`prenomsClt` AS PRENOMS,`telClt` AS TELEPHONE,fraisAbon as FRAIS,dateEnreg as 'DATE ENREGISTREMENT' FROM clients WHERE nomClt like '" + nom + "%';";
            command.Connection = con.GetConnection();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = command;
            DataTable data = new DataTable();
            adapter.Fill(data);
            return data;
        }

        public bool ajoutClient(string nom, string prenoms, string tel, double frais, DateTime date)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "INSERT INTO `clients` VALUES (idClt,@nom,@prenoms,@tel,@frais,@date);";
            command.Connection = con.GetConnection();
            command.Parameters.Add("@nom", MySqlDbType.VarChar).Value = nom;
            command.Parameters.Add("@prenoms", MySqlDbType.VarChar).Value = prenoms;
            command.Parameters.Add("@tel", MySqlDbType.VarChar).Value = tel;
            command.Parameters.Add("@frais", MySqlDbType.Double).Value = frais;
            command.Parameters.Add("@date", MySqlDbType.Date).Value = date;

            con.openConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                con.closeConnection();
                return true;
            }
            else
            {
                con.closeConnection();
                return false;
            }
        }

        public bool MAJClients(int id, string nom, string prenoms, string tel, double frais, DateTime date)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "UPDATE `clients`  SET nomClt=@nom,prenomsClt=@prenoms,telClt=@tel,fraisAbon=@frais,dateEnreg=@date WHERE idClt=@id;";
            command.Connection = con.GetConnection();
            command.Parameters.Add("@id", MySqlDbType.Int32).Value = id;
            command.Parameters.Add("@nom", MySqlDbType.VarChar).Value = nom;
            command.Parameters.Add("@prenoms", MySqlDbType.VarChar).Value = prenoms;
            command.Parameters.Add("@tel", MySqlDbType.VarChar).Value = tel;
            command.Parameters.Add("@frais", MySqlDbType.Double).Value = frais;
            command.Parameters.Add("@date", MySqlDbType.Date).Value = date;

            con.openConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                con.closeConnection();
                return true;
            }
            else
            {
                con.closeConnection();
                return false;
            }
        }

        public bool deleteClient(int id)
        {
            MySqlCommand command = new MySqlCommand();
            command.CommandText = "DELETE FROM `clients` WHERE idClt=@id;";
            command.Connection = con.GetConnection();
            command.Parameters.Add("@id", MySqlDbType.Int32).Value = id;

            con.openConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                con.closeConnection();
                return true;
            }
            else
            {
                con.closeConnection();
                return false;
            }
        }
    }
}
